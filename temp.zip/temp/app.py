from flask import Flask, render_template, url_for, request, session, redirect, make_response
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import secrets, os

app = Flask(__name__)
app.config['SECRET_KEY'] = secrets.token_urlsafe(16)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.abspath('./site.db')

sql = SQLAlchemy(app)
app.app_context().push()
class UsersTable(sql.Model):
    id = sql.Column(sql.Integer, primary_key=True)
    login = sql.Column(sql.String, unique=True)
    password = sql.Column(sql.String)

with app.app_context():
    sql.create_all()

@app.route("/")
@app.route("/index")
def index():
    return render_template("index.html")

@app.route("/login", methods=["POST", "GET"])
def register():
    if (request.method == "POST"):
        try:
            print(request.form)
            user = UsersTable(login=request.form['login'], password=request.form['password'])
            sql.session.add(user)
            sql.session.commit()
            session['username'] = request.form['login']
            return redirect(url_for('index'))
        except Exception as e:
            print("DB Error!")
    return render_template("index.html")

@app.errorhandler(404)
def pageNotFound(error):
    return redirect(url_for('index'))

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=True)